/*
 Playground to see IF-THEN-ELSE commands in action, 
 as well as boolean variables
 */
package testif_else;

public class TestIF_ELSE {

    public static void main(String[] args) {
        /* test 1: try to change the value of playerAlive, 
         run and see the different outcome
         */
        boolean playerAlive;
        playerAlive = true;
        if (playerAlive) {
            System.out.println("you are still alive!");
        }
        if (playerAlive == false) {
            System.out.println("oops...");
        }

        // test 2
        boolean whoKnows;
        whoKnows = 2 > 3;
        System.out.println("is 2 larger than 3?");
        System.out.println(whoKnows);

        // test 3: try changing the gotBonus to  true , and see the result
        boolean gotBonus = false;
        if (gotBonus == true) {
            System.out.println("great!");
        } else {
            System.out.println("too bad :(");
        }

    }

}
