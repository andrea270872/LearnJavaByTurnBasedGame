/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 2_1
 * Alternative0 way: using StringBuilder instead of the substring method
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        StringBuilder map = new StringBuilder("WEEHEEPEX");
        int heroPos = map.indexOf("H"); // automatic finding H in the map
        boolean isGameRunning = true;
        
        while (isGameRunning){
            System.out.println(map);
            System.out.println("Type  a  to move left,");
            System.out.println("      d  to move right,");
            System.out.println("      q  to quit. ");
            System.out.println("Press ENTER to confirm your command.");
            String s = in.nextLine();
            
            if (s.equals("q")){
                isGameRunning = false;
            } else {
                // player's move
                if (s.equals("a")){
                    map.setCharAt(heroPos-1,'H');
                    map.setCharAt(heroPos  ,'E');
                    heroPos = heroPos-1;
                }
                if (s.equals("d")){
                    map.setCharAt(heroPos  ,'E');
                    map.setCharAt(heroPos+1,'H');
                    heroPos = heroPos+1;
                }                
            }
        } // end of the while loop
        System.out.println(map);
        System.out.println("Goodbye");
    }    
}
