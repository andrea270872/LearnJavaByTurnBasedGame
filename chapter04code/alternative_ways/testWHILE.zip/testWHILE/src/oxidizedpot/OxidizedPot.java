/*
 OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 By Andrea Valente (anva@mmmi.sdu.dk) 
 May 2016
 
 A simple test of how to use a WHILE loop to keep the game running 
*/
package oxidizedpot;

import java.util.Scanner;

/**
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean isGameRunning = true;
        
        while (isGameRunning){
            System.out.println("Type antyhing you like,");
            System.out.println("      q  to quit. ");
            System.out.println("Press ENTER to confirm your command.");
            String s = in.nextLine();
            System.out.println("You typed: " + s);
            if (s.equals("q")){
                isGameRunning = false;
            }
        } // end of the while loop
        System.out.println("Goodbye");
    }    
}
