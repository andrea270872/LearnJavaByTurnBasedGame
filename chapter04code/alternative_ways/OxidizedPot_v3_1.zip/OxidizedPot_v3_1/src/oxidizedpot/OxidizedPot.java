/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 3_1
 * The code in OxidizedPot_v3 is not very nice: I had to rewrite almost 
 * the same code inside both IFs that control which move the player wants to do. 
 * This is called "code duplication" and it is considered a bad idea.
 * Here I fix that by a typical trick used in games: I calculate where
 * the hero should land and only move if there are no conflicts or collisions.
 * 
 * I'm using a typical trick in games: I calculate on which tile the H 
 * should land, then see if there are any problems with that tile, then
 * if possible, perform the actual move.
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String map = "WPEHEEPEXEW";
        int heroPos = 3;
        boolean isGameRunning = true;
        boolean reachedTheX = false; 
        
        while (isGameRunning){
            System.out.println(map);
            System.out.println("Type  a  to move left,");
            System.out.println("      d  to move right,");
            System.out.println("      q  to quit. ");
            System.out.println("Press ENTER to confirm your command.");
            String s = in.nextLine();
            
            if (s.equals("q")){
                isGameRunning = false;
            } else {
                // player's move
                int newHeroPos = heroPos;                
                if (s.equals("a")){
                    newHeroPos = heroPos-1;
                }
                if (s.equals("d")){
                    newHeroPos = heroPos+1;
                }

                // check the rules to see how to move
                char targetTile = map.charAt(newHeroPos);
                if (targetTile=='E'){ // landing on an empty tile
                    map = map.substring(0,newHeroPos) + "H" +
                            map.substring(newHeroPos+1);
                    map = map.substring(0,heroPos) + "E" +
                            map.substring(heroPos+1);
                }
                if (targetTile=='P'){ // landing on a pot
                    // erase the pot
                    map = map.substring(0,newHeroPos) + "E" +
                            map.substring(newHeroPos+1);
                    // do not move the hero
                    newHeroPos = heroPos;
                    System.out.println("the pot is destroyed");
                }
                if (targetTile=='W'){ // landing on a wall
                    // nothing happens
                    newHeroPos = heroPos;
                    System.out.println("cannot move, there is a wall");
                }
                if (targetTile=='X'){ // landing on the exit
                    map = map.substring(0,newHeroPos) + "H" +
                            map.substring(newHeroPos+1);
                    map = map.substring(0,heroPos) + "E" +
                            map.substring(heroPos+1);

                    isGameRunning = false;
                    reachedTheX = true;
                }
            
                // perform the move
                heroPos = newHeroPos;
            }
        } // end of the while loop
        System.out.println(map);
        
        if (reachedTheX==true){
            System.out.println("*** [][][][][][][][][][][][] ***");
            System.out.println("*** You won! Congratulations ***");
            System.out.println("*** [][][][][][][][][][][][] ***");
        }
        
        System.out.println("Goodbye");
    }    
}
