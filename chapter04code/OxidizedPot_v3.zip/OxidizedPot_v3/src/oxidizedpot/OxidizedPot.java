/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 3
 * - Oxidized Pot is now playable (at least in a minimal way)
 * - added a WHILE loop that keeps the game running 
 * - rules about H stepping over a P, a W and an X.
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String map = "WPEHEEPEXEW";
        int heroPos = 3;
        boolean isGameRunning = true;
        boolean reachedTheX = false; 
        
        while (isGameRunning){
            System.out.println(map);
            System.out.println("Type  a  to move left,");
            System.out.println("      d  to move right,");
            System.out.println("      q  to quit. ");
            System.out.println("Press ENTER to confirm your command.");
            String s = in.nextLine();
            
            if (s.equals("q")){
                isGameRunning = false;
            } else {
                // player's move
                if (s.equals("a")){
                    char targetTile = map.charAt(heroPos-1);
                    if (targetTile=='E'){ // landing on an empty tile
                        map = map.substring(0,heroPos-1) + 
                              "HE" +
                              map.substring(heroPos+1);
                        heroPos = heroPos-1;
                    }
                    if (targetTile=='P'){ // landing on a pot
                        map = map.substring(0,heroPos-1) + 
                              "E" +
                              map.substring(heroPos);
                        System.out.println("the pot is destroyed");
                    }
                    if (targetTile=='W'){ // landing on a wall
                        // nothing happens
                        System.out.println("cannot move, there is a wall");
                    }
                    if (targetTile=='X'){ // landing on the exit
                        map = map.substring(0,heroPos-1) + 
                              "HE" +
                              map.substring(heroPos+1);
                        heroPos = heroPos-1;

                        isGameRunning = false;
                        reachedTheX = true;
                    }
                }
                if (s.equals("d")){
                    char targetTile = map.charAt(heroPos+1);
                    if (targetTile=='E'){ // landing on an empty tile
                        map = map.substring(0,heroPos) + 
                              "EH" +
                              map.substring(heroPos+2);
                        heroPos = heroPos+1;
                    }
                    if (targetTile=='P'){ // landing on a pot
                        map = map.substring(0,heroPos+1) + 
                              "E" +
                              map.substring(heroPos+2);
                        System.out.println("the pot is destroyed");
                    }
                    if (targetTile=='W'){ // landing on a wall
                        // nothing happens
                        System.out.println("cannot move, there is a wall");
                    }
                    if (targetTile=='X'){ // landing on the exit
                        map = map.substring(0,heroPos) + 
                              "EH" +
                              map.substring(heroPos+2);
                        heroPos = heroPos+1;

                        isGameRunning = false;
                        reachedTheX = true;
                    }
                    
                }                
            }
        } // end of the while loop
        System.out.println(map);
        
        if (reachedTheX==true){
            System.out.println("*** [][][][][][][][][][][][] ***");
            System.out.println("*** You won! Congratulations ***");
            System.out.println("*** [][][][][][][][][][][][] ***");
        }
        
        System.out.println("Goodbye");
    }    
}
