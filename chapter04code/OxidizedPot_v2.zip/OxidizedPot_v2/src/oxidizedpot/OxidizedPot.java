/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 2 
 * - Oxidized Pot is now playable (at least in a minimal way)
 * - added a WHILE loop that keeps the game running 
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String map = "WEEHEEPEX";
        int heroPos = 3;
        boolean isGameRunning = true;
        
        while (isGameRunning){
            System.out.println(map);
            System.out.println("Type  a  to move left,");
            System.out.println("      d  to move right,");
            System.out.println("      q  to quit. ");
            System.out.println("Press ENTER to confirm your command.");
            String s = in.nextLine();
            
            if (s.equals("q")){
                isGameRunning = false;
            } else {
                // player's move
                if (s.equals("a")){
                    map = map.substring(0,heroPos-1) + 
                          "HE" +
                          map.substring(heroPos+1);

                    heroPos = heroPos-1;
                }
                if (s.equals("d")){
                    map = map.substring(0,heroPos) + 
                          "EH" +
                          map.substring(heroPos+2);

                    heroPos = heroPos+1;
                }                
            }
        } // end of the while loop
        System.out.println(map);
        System.out.println("Goodbye");
    }    
}
