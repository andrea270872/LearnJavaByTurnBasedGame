/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 0
 */
package oxidizedpot;

/**
 * @author Andrea
 */
public class OxidizedPot {

    public static void main(String[] args) {
        String state1 = "WEHPEX";
        String state2 = "WEHEEX";
        String state3 = "WEEHEX";
        String state4 = "WEEEHX";
        String state5 = "WEEEEH";
        
        System.out.println(state1);
        System.out.println(state2);
        System.out.println(state3);
        System.out.println(state4);
        System.out.println(state5);
        System.out.println("Player wins");
    }
    
}
