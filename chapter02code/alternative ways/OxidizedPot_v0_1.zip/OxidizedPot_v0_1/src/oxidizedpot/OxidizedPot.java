/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 0_1
 * Alternative way to represent the situation in the game (aka game state).
 * I also renamed the variables to show that they can be totally arbitrary.
 */
package oxidizedpot;

/**
 * @author Andrea
 */
public class OxidizedPot {

    public static void main(String[] args) {
        /*
        Legend: 
        - # is a wall
        - . is an empty tile
        - H is the hero
        - 8 is a pot
        - * is the exit
        */
        String andrea  = "#.H8.*";
        String valente = "#.H..*";
        String today = "#..H.*";
        String yesterday = "#...H*";
        String moon = "#....H";
        
        System.out.println(andrea);
        System.out.println(valente + " The pot is now broken!");
        System.out.println(today);
        System.out.println(yesterday);
        System.out.println(moon);
        System.out.println("Player wins");
    }
    
}
