/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * May 2016
 *
 *
 * Version 1_1 
 * - Instead of cutting and putting back together my string map in the 
 * same line of code, I can use temporary variables
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        String map = "WEEHEEPEX";
        int heroPos = 3;
        
        System.out.println(map);            
        System.out.println("Type  a  or  d  (to move left or right), then Enter");
        Scanner in = new Scanner(System.in);
        String s = in.nextLine();

        // "unhappy".substring(2) returns "happy"
        // "hamburger".substring(4, 8) returns "urge"
        if (s.equals("a")){
            String temp1,temp2;
            temp1 = map.substring(0,heroPos-1);
            temp2 = map.substring(heroPos+1);
            map = temp1 + "HE" + temp2;
            heroPos = heroPos-1;
        }
        if (s.equals("d")){
            String temp1,temp2;
            temp1 = map.substring(0,heroPos);
            temp2 = map.substring(heroPos+2);
            map = temp1 + "EH" + temp2;            
            heroPos = heroPos+1;
        }
        
        System.out.println(map);
        System.out.println();        
    }    
}
