/*
 * OxidizedPot (a simple remake of Nitrome's Rust Bucket)
 * By Andrea Valente (anva@mmmi.sdu.dk) 
 * April 2016
 *
 *
 * Version 1
 * - Oxidized Pot is now playable (at least in a minimal way)
 */
package oxidizedpot;

import java.util.Scanner;

/**
 *
 * @author Andrea
 */
public class OxidizedPot {
    public static void main(String[] args) {
        String map = "WEEHEEPEX";
        int heroPos = 3;
        
        System.out.println(map);            
        System.out.println("Type  a  or  d  (to move left or right), then Enter");
        Scanner in = new Scanner(System.in);
        String s = in.nextLine();

        // "unhappy".substring(2) returns "happy"
        // "hamburger".substring(4, 8) returns "urge"
        if (s.equals("a")){
            map = map.substring(0,heroPos-1) + 
                  "HE" +
                  map.substring(heroPos+1);
            
            heroPos = heroPos-1;
        }
        if (s.equals("d")){
            map = map.substring(0,heroPos) + 
                  "EH" +
                  map.substring(heroPos+2);
            
            heroPos = heroPos+1;
        }
        
        System.out.println(map);
        System.out.println();        
    }    
}
